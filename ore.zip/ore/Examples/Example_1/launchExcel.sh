#!/bin/bash

open -b com.microsoft.Excel run.xlsm &
