#!/bin/bash

/Applications/LibreOffice.app/Contents/MacOS/python calc_view.py &
