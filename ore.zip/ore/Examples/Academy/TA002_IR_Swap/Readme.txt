1) Portfolio

	Portfolio containing a single trade:
	A Interest Rate Swap exchanging a yearly fixed rate of 4% vs a bi-annualy EUR-EURIBOR-6M
	with maturity 20Y (01-Mar-2036)

2) Market

   Pseudo market data as of 2016-02-05

3) Pricing (see .PNG image file in the same folder)

   Eonia Discounting

4) Analytics

   NPV
   Cashflow
   Curves

5) Run Example

   python run.py