SIMM Calculator called with an external CRIF file

The latest supported SIMM version is 2.6 (aka 2.5.6)

For SIMM version >= 2.2 we provide both MPoR=10d and MPoR=1d versions.
