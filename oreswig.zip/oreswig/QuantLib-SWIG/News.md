
Changes for QuantLib-SWIG 1.31.1
================================

QuantLib-SWIG 1.31.1 is a bug-fix release for version 1.31.

It includes a change in the underlying C++ library that fixes a
regression that could cause a segmentation fault when bootstrapping an
interest-rate curve using OIS rates.
