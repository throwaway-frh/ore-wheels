﻿# ore-wheels

|   | macOS Intel | macOS Apple Silicon | Windows 64bit | Windows 32bit | manylinux<br/>musllinux x86_64 |
|----------------|----|-----|-----|-----|----|
| CPython 3.7    | ✅ | N/A | N/A   | N/A | ✅ |
| CPython 3.8    | ✅ | ✅  |✅  | ✅  | ✅ | 
| CPython 3.9    | ✅ | ✅  | ✅  | ✅  | ✅ | 
| CPython 3.10   | ✅ | ✅  | ✅   | ✅ | ✅ | 
| CPython 3.11   | ✅ | ✅  |✅  | ✅ | ✅ | 
| CPython 3.12   | ✅ | ✅  | ✅   | ✅ | ✅ |  
| PyPy 3.7 v7.3  | ✅ | N/A | ✅  | N/A | ✅¹ | 
| PyPy 3.8 v7.3  | ✅ | N/A | ✅  | N/A | ✅¹ | 
| PyPy 3.9 v7.3  | ✅ | N/A | ✅  | N/A | ✅¹ | 
| PyPy 3.10 v7.3 | ✅ | N/A | ✅  | N/A | ✅¹ | 

<sup>¹ PyPy is only supported for manylinux wheels, not musllinux.</sup><br>